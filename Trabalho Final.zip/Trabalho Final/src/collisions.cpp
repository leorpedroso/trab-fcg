#include <glm/gtc/type_ptr.hpp>

bool Collision(glm::vec4 pos1, glm::vec4 pos2, glm::vec3 sz1, glm::vec3 sz2) // AABB - AABB collision
{
    //Recebe a posicao do objeto 1, posicao do objeto 2, tamanho do objeto 1, e tamanho do objeto 2

    glm::vec3 halfSz1 = glm::vec3(sz1[0]/2,sz1[1]/2,sz1[2]/2);
    glm::vec3 halfSz2 = glm::vec3(sz2[0]/2,sz2[1]/2,sz2[2]/2);
    bool collisionX = (pos1[0] + halfSz1[0] >= pos2[0] &&
        pos2[0] + halfSz2[0] >= pos1[0]) ||
        (pos2[0] - halfSz2[0] <= pos1[0] &&
        pos1[0] - halfSz1[0] <= pos2[0]);
    bool collisionY = (pos1[1] + halfSz1[1] >= pos2[1] &&
        pos2[1] + halfSz2[1] >= pos1[1]) ||
        (pos2[1] - halfSz2[1] <= pos1[1] &&
        pos1[1] - halfSz1[1] <= pos2[1]);
    bool collisionZ = (pos1[2] + halfSz1[2] >= pos2[2] &&
        pos2[2] + halfSz2[2] >= pos1[2]) ||
        (pos2[2] - halfSz2[2] <= pos1[2] &&
        pos1[2] - halfSz1[2] <= pos2[2]);
    return collisionX && collisionY && collisionZ;
}

// https://developer.mozilla.org/en-US/docs/Games/Techniques/3D_collision_detection#point_vs._aabb
bool ShotCollision(glm::vec4 posPoint, glm::vec4 bbox_min, glm::vec4 bbox_max)  // Point - AABB collision
{
    bool collisionX =  bbox_max.x >= posPoint.x && bbox_min.x <= posPoint.x;
    bool collisionY =  bbox_max.y >= posPoint.y && bbox_min.y <= posPoint.y;
    bool collisionZ =  bbox_max.z >= posPoint.z && bbox_min.z <= posPoint.z;

    return collisionX && collisionY && collisionZ ;
}


bool ArmadilloCollision(glm::vec4 pos1, glm::vec3 sz1, glm::vec4 bbox_max_world_armadillo, glm::vec4 bbox_min_world_armadillo)
{
    glm::vec3 halfSz1 = glm::vec3(sz1[0]/2,sz1[1]/2,sz1[2]/2);

    bool collisionX = (pos1[0] + halfSz1[0] >= bbox_min_world_armadillo.x &&
        bbox_max_world_armadillo.x >= pos1[0]);

    bool collisionY = (pos1[1] + halfSz1[1] >= bbox_min_world_armadillo.y &&
        bbox_max_world_armadillo.y >= pos1[1]);

    bool collisionZ = (pos1[2] + halfSz1[2] >= bbox_min_world_armadillo.z &&
        bbox_max_world_armadillo.z >= pos1[2]);

    return collisionX && collisionY && collisionZ;}
